import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { CandlestickBackground } from '@/components/backgrounds/CandlestickBackground';
import { ParticleBackground } from '@/components/backgrounds/ParticleBackground';
import { Navigation } from '@/components/Navigation';
import { AuthModal } from '@/components/AuthModal';
import { Toast } from '@/components/Toast';
import { Hero } from '@/sections/Hero';
import { Courses } from '@/sections/Courses';
import { Payment } from '@/sections/Payment';
import { AdminDashboard } from '@/sections/AdminDashboard';
import { StudentDashboard } from '@/sections/StudentDashboard';
import { CourseDetail } from '@/sections/CourseDetail';
import { useAppStore } from '@/store/appStore';
import { Button } from '@/components/ui/button';
import { ArrowRight, TrendingUp } from 'lucide-react';
import './App.css';

function App() {
  const { currentView, setView, isAuthenticated, currentUser } = useAppStore();
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');

  // Handle protected routes
  useEffect(() => {
    if ((currentView === 'admin' && currentUser?.role !== 'admin') ||
        (currentView === 'student-dashboard' && !isAuthenticated)) {
      setAuthModalOpen(true);
    }
  }, [currentView, isAuthenticated, currentUser]);

  const handleGetStarted = () => {
    if (isAuthenticated) {
      setView('courses');
    } else {
      setAuthMode('register');
      setAuthModalOpen(true);
    }
  };

  const handleLogin = () => {
    setAuthMode('login');
    setAuthModalOpen(true);
  };

  const renderView = () => {
    switch (currentView) {
      case 'landing':
        return (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <Hero />
            
            {/* Features Section */}
            <section className="py-20 relative">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  className="text-center mb-16"
                >
                  <h2 className="text-3xl md:text-4xl font-bold mb-4">
                    <span className="text-gradient">Why Choose TradeMaster?</span>
                  </h2>
                  <p className="text-gray-400 max-w-2xl mx-auto">
                    Learn from the best with our comprehensive trading education platform
                  </p>
                </motion.div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  {[
                    {
                      title: 'Password Protected',
                      description: 'Each course is protected with a unique password. Only authorized students can purchase and access premium content.',
                      icon: '🔒',
                      color: 'from-emerald-400 to-teal-500',
                    },
                    {
                      title: 'UPI Payment',
                      description: 'Quick and secure payments via UPI. Scan QR code, pay, and get instant access to your courses.',
                      icon: '💳',
                      color: 'from-amber-400 to-orange-500',
                    },
                    {
                      title: 'Expert Mentors',
                      description: 'Learn from professional traders with years of experience in stock, crypto, and forex markets.',
                      icon: '👨‍🏫',
                      color: 'from-purple-400 to-pink-500',
                    },
                  ].map((feature, index) => (
                    <motion.div
                      key={feature.title}
                      initial={{ opacity: 0, y: 20 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: index * 0.1 }}
                      className="glass rounded-2xl p-6 hover:border-emerald-500/30 transition-colors"
                    >
                      <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${feature.color} flex items-center justify-center text-3xl mb-4`}>
                        {feature.icon}
                      </div>
                      <h3 className="text-xl font-semibold text-white mb-3">{feature.title}</h3>
                      <p className="text-gray-400">{feature.description}</p>
                    </motion.div>
                  ))}
                </div>
              </div>
            </section>

            {/* CTA Section */}
            <section className="py-20 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-r from-emerald-500/10 to-teal-500/10" />
              <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                >
                  <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
                    Ready to Start Your Trading Journey?
                  </h2>
                  <p className="text-gray-400 mb-8 max-w-xl mx-auto">
                    Join thousands of students learning to trade with confidence. 
                    Get access to premium courses with password protection.
                  </p>
                  <div className="flex flex-col sm:flex-row gap-4 justify-center">
                    <Button
                      size="lg"
                      onClick={handleGetStarted}
                      className="bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white px-8"
                    >
                      Get Started Free
                      <ArrowRight className="w-5 h-5 ml-2" />
                    </Button>
                    <Button
                      size="lg"
                      variant="outline"
                      onClick={() => setView('courses')}
                      className="border-white/20 text-white hover:bg-white/5"
                    >
                      Browse Courses
                    </Button>
                  </div>
                </motion.div>
              </div>
            </section>

            {/* Footer */}
            <footer className="border-t border-white/5 py-12">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
                  <div>
                    <div className="flex items-center gap-2 mb-4">
                      <TrendingUp className="w-6 h-6 text-emerald-400" />
                      <span className="text-lg font-bold text-white">TradeMaster</span>
                    </div>
                    <p className="text-gray-400 text-sm">
                      Premium trading education platform with password-protected courses and UPI payments.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-white mb-4">Quick Links</h4>
                    <ul className="space-y-2 text-sm text-gray-400">
                      <li><button onClick={() => setView('courses')} className="hover:text-emerald-400">Courses</button></li>
                      <li><button onClick={() => setView('landing')} className="hover:text-emerald-400">About</button></li>
                      <li><button onClick={handleLogin} className="hover:text-emerald-400">Login</button></li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold text-white mb-4">Categories</h4>
                    <ul className="space-y-2 text-sm text-gray-400">
                      <li>Stock Market</li>
                      <li>Technical Analysis</li>
                      <li>Options Trading</li>
                      <li>Crypto</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold text-white mb-4">Contact</h4>
                    <ul className="space-y-2 text-sm text-gray-400">
                      <li>support@trademaster.com</li>
                      <li>+91 98765 43210</li>
                    </ul>
                  </div>
                </div>
                <div className="border-t border-white/5 mt-8 pt-8 text-center text-sm text-gray-500">
                  © 2024 TradeMaster Academy. All rights reserved.
                </div>
              </div>
            </footer>
          </motion.div>
        );
      case 'courses':
        return (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <Courses />
          </motion.div>
        );
      case 'course-detail':
        return (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <CourseDetail />
          </motion.div>
        );
      case 'payment':
        return (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <Payment />
          </motion.div>
        );
      case 'admin':
        return currentUser?.role === 'admin' ? (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <AdminDashboard />
          </motion.div>
        ) : null;
      case 'student-dashboard':
        return isAuthenticated ? (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <StudentDashboard />
          </motion.div>
        ) : null;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground relative">
      {/* Animated Backgrounds */}
      <CandlestickBackground />
      <ParticleBackground />
      
      {/* Navigation */}
      <Navigation />
      
      {/* Main Content */}
      <main className="relative z-10">
        <AnimatePresence mode="wait">
          {renderView()}
        </AnimatePresence>
      </main>
      
      {/* Auth Modal */}
      <AuthModal 
        isOpen={authModalOpen} 
        onClose={() => setAuthModalOpen(false)} 
        defaultMode={authMode}
      />
      
      {/* Toast Notifications */}
      <Toast />
    </div>
  );
}

export default App;
