import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  TrendingUp, 
  Menu, 
  X, 
  User, 
  LogOut, 
  LayoutDashboard,
  BookOpen,
  Home
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAppStore } from '@/store/appStore';
import type { View } from '@/types';

export function Navigation() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { currentUser, isAuthenticated, logout, setView, currentView } = useAppStore();

  const navItems: { label: string; view: View; icon: React.ReactNode; show: boolean }[] = [
    { label: 'Home', view: 'landing', icon: <Home className="w-4 h-4" />, show: true },
    { label: 'Courses', view: 'courses', icon: <BookOpen className="w-4 h-4" />, show: true },
    { label: 'Dashboard', view: 'student-dashboard', icon: <LayoutDashboard className="w-4 h-4" />, show: isAuthenticated },
    { label: 'Admin', view: 'admin', icon: <User className="w-4 h-4" />, show: currentUser?.role === 'admin' },
  ];

  const handleNavClick = (view: View) => {
    setView(view);
    setIsMenuOpen(false);
  };

  return (
    <motion.nav
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      className="fixed top-0 left-0 right-0 z-50 glass-dark border-b border-white/5"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <motion.div
            className="flex items-center gap-2 cursor-pointer"
            whileHover={{ scale: 1.02 }}
            onClick={() => handleNavClick('landing')}
          >
            <div className="relative">
              <TrendingUp className="w-8 h-8 text-emerald-400" />
              <motion.div
                className="absolute inset-0 bg-emerald-400/30 blur-xl rounded-full"
                animate={{ scale: [1, 1.2, 1], opacity: [0.5, 0.8, 0.5] }}
                transition={{ duration: 2, repeat: Infinity }}
              />
            </div>
            <span className="text-xl font-bold text-gradient">
              TradeMaster
            </span>
          </motion.div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-1">
            {navItems.filter(item => item.show).map((item) => (
              <Button
                key={item.view}
                variant="ghost"
                size="sm"
                onClick={() => handleNavClick(item.view)}
                className={`flex items-center gap-2 ${
                  currentView === item.view 
                    ? 'text-emerald-400 bg-emerald-400/10' 
                    : 'text-gray-300 hover:text-white hover:bg-white/5'
                }`}
              >
                {item.icon}
                {item.label}
              </Button>
            ))}
          </div>

          {/* Auth Buttons */}
          <div className="hidden md:flex items-center gap-3">
            {isAuthenticated ? (
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/5">
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-emerald-400 to-teal-500 flex items-center justify-center text-sm font-semibold">
                    {currentUser?.name.charAt(0).toUpperCase()}
                  </div>
                  <span className="text-sm text-gray-300">{currentUser?.name}</span>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={logout}
                  className="text-gray-400 hover:text-red-400 hover:bg-red-400/10"
                >
                  <LogOut className="w-5 h-5" />
                </Button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleNavClick('landing')}
                  className="text-gray-300 hover:text-white"
                >
                  Login
                </Button>
                <Button
                  size="sm"
                  onClick={() => handleNavClick('landing')}
                  className="bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600"
                >
                  Get Started
                </Button>
              </div>
            )}
          </div>

          {/* Mobile Menu Button */}
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden text-gray-300"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </Button>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden glass-dark border-t border-white/5"
          >
            <div className="px-4 py-4 space-y-2">
              {navItems.filter(item => item.show).map((item) => (
                <Button
                  key={item.view}
                  variant="ghost"
                  className={`w-full justify-start gap-3 ${
                    currentView === item.view 
                      ? 'text-emerald-400 bg-emerald-400/10' 
                      : 'text-gray-300'
                  }`}
                  onClick={() => handleNavClick(item.view)}
                >
                  {item.icon}
                  {item.label}
                </Button>
              ))}
              
              {isAuthenticated ? (
                <Button
                  variant="ghost"
                  className="w-full justify-start gap-3 text-red-400"
                  onClick={logout}
                >
                  <LogOut className="w-4 h-4" />
                  Logout
                </Button>
              ) : (
                <div className="pt-2 space-y-2">
                  <Button
                    variant="outline"
                    className="w-full border-white/10"
                    onClick={() => handleNavClick('landing')}
                  >
                    Login
                  </Button>
                  <Button
                    className="w-full bg-gradient-to-r from-emerald-500 to-teal-500"
                    onClick={() => handleNavClick('landing')}
                  >
                    Get Started
                  </Button>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.nav>
  );
}
