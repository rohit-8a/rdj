import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Lock, 
  Play, 
  Clock, 
  Users, 
  Star, 
  Search,
  ArrowRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useAppStore } from '@/store/appStore';
import type { Course } from '@/types';

export function Courses() {
  const { courses, hasPurchased, setView, setSelectedCourse } = useAppStore();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedLevel, setSelectedLevel] = useState<string>('all');
  const [passwordDialog, setPasswordDialog] = useState<{ open: boolean; course: Course | null }>({ open: false, course: null });
  const [password, setPassword] = useState('');
  const [passwordError, setPasswordError] = useState('');

  const filteredCourses = courses.filter(course => {
    const matchesSearch = course.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         course.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         course.category.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesLevel = selectedLevel === 'all' || course.level === selectedLevel;
    return matchesSearch && matchesLevel;
  });

  const handleCourseClick = (course: Course) => {
    if (hasPurchased(course.id)) {
      setSelectedCourse(course.id);
      setView('course-detail');
    } else {
      setPasswordDialog({ open: true, course });
      setPassword('');
      setPasswordError('');
    }
  };

  const handlePasswordSubmit = () => {
    if (!passwordDialog.course) return;
    
    if (password === passwordDialog.course.password) {
      setPasswordDialog({ open: false, course: null });
      setSelectedCourse(passwordDialog.course.id);
      setView('payment');
    } else {
      setPasswordError('Incorrect password. Please try again.');
    }
  };

  const handleBuyClick = (course: Course, e: React.MouseEvent) => {
    e.stopPropagation();
    setPasswordDialog({ open: true, course });
    setPassword('');
    setPasswordError('');
  };

  const levels = ['all', 'beginner', 'intermediate', 'advanced'];

  return (
    <section className="relative min-h-screen pt-24 pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4">
            <span className="text-gradient">Premium Trading Courses</span>
          </h1>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            Unlock expert-led courses with password protection. Enter the course password to purchase and access exclusive content.
          </p>
        </motion.div>

        {/* Search and Filter */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="flex flex-col sm:flex-row gap-4 mb-8"
        >
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
            <Input
              placeholder="Search courses..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-white/5 border-white/10 text-white placeholder:text-gray-500"
            />
          </div>
          <div className="flex gap-2">
            {levels.map((level) => (
              <Button
                key={level}
                variant={selectedLevel === level ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedLevel(level)}
                className={`capitalize ${
                  selectedLevel === level 
                    ? 'bg-emerald-500 hover:bg-emerald-600' 
                    : 'border-white/10 text-gray-300 hover:bg-white/5'
                }`}
              >
                {level}
              </Button>
            ))}
          </div>
        </motion.div>

        {/* Course Grid */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          <AnimatePresence mode="popLayout">
            {filteredCourses.map((course, index) => {
              const isPurchased = hasPurchased(course.id);
              const discount = course.originalPrice 
                ? Math.round(((course.originalPrice - course.price) / course.originalPrice) * 100)
                : 0;

              return (
                <motion.div
                  key={course.id}
                  layout
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  transition={{ delay: index * 0.1 }}
                  onClick={() => handleCourseClick(course)}
                  className="group relative glass rounded-2xl overflow-hidden cursor-pointer hover:border-emerald-500/30 transition-colors"
                >
                  {/* Thumbnail */}
                  <div className="relative h-48 overflow-hidden">
                    <img
                      src={course.thumbnail}
                      alt={course.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-background via-background/50 to-transparent" />
                    
                    {/* Lock overlay */}
                    {!isPurchased && (
                      <div className="absolute inset-0 flex items-center justify-center bg-black/40 backdrop-blur-sm">
                        <motion.div
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                          className="w-16 h-16 rounded-full bg-white/10 flex items-center justify-center"
                        >
                          <Lock className="w-8 h-8 text-white" />
                        </motion.div>
                      </div>
                    )}

                    {/* Level badge */}
                    <Badge className="absolute top-3 left-3 bg-black/60 text-white border-0">
                      {course.level}
                    </Badge>

                    {/* Discount badge */}
                    {discount > 0 && (
                      <Badge className="absolute top-3 right-3 bg-emerald-500 text-white border-0">
                        {discount}% OFF
                      </Badge>
                    )}
                  </div>

                  {/* Content */}
                  <div className="p-5">
                    <div className="flex items-center gap-2 text-sm text-gray-500 mb-2">
                      <span className="text-emerald-400">{course.category}</span>
                      <span>•</span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {course.duration}
                      </span>
                    </div>

                    <h3 className="text-xl font-semibold text-white mb-2 group-hover:text-emerald-400 transition-colors">
                      {course.title}
                    </h3>

                    <p className="text-gray-400 text-sm mb-4 line-clamp-2">
                      {course.description}
                    </p>

                    <div className="flex items-center gap-4 mb-4">
                      <div className="flex items-center gap-1">
                        <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
                        <span className="text-sm text-gray-300">4.9</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Users className="w-4 h-4 text-gray-500" />
                        <span className="text-sm text-gray-300">2.5k+ students</span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-baseline gap-2">
                        <span className="text-2xl font-bold text-white">
                          ₹{course.price.toLocaleString()}
                        </span>
                        {course.originalPrice && (
                          <span className="text-sm text-gray-500 line-through">
                            ₹{course.originalPrice.toLocaleString()}
                          </span>
                        )}
                      </div>

                      {isPurchased ? (
                        <Button
                          size="sm"
                          className="bg-emerald-500 hover:bg-emerald-600"
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedCourse(course.id);
                            setView('course-detail');
                          }}
                        >
                          <Play className="w-4 h-4 mr-1" />
                          Watch
                        </Button>
                      ) : (
                        <Button
                          size="sm"
                          variant="outline"
                          className="border-emerald-500/50 text-emerald-400 hover:bg-emerald-500/10"
                          onClick={(e) => handleBuyClick(course, e)}
                        >
                          <Lock className="w-4 h-4 mr-1" />
                          Unlock
                        </Button>
                      )}
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </motion.div>

        {/* Empty state */}
        {filteredCourses.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-16"
          >
            <div className="w-20 h-20 mx-auto mb-4 rounded-full bg-white/5 flex items-center justify-center">
              <Search className="w-10 h-10 text-gray-500" />
            </div>
            <h3 className="text-xl font-semibold text-white mb-2">No courses found</h3>
            <p className="text-gray-400">Try adjusting your search or filters</p>
          </motion.div>
        )}
      </div>

      {/* Password Dialog */}
      <Dialog open={passwordDialog.open} onOpenChange={(open) => setPasswordDialog({ open, course: open ? passwordDialog.course : null })}>
        <DialogContent className="bg-[#0a0a0a] border-white/10 text-white max-w-md">
          <DialogHeader>
            <DialogTitle className="text-xl flex items-center gap-2">
              <Lock className="w-5 h-5 text-emerald-400" />
              Enter Course Password
            </DialogTitle>
          </DialogHeader>
          
          {passwordDialog.course && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-white/5">
                <div className="font-semibold text-white mb-1">{passwordDialog.course.title}</div>
                <div className="text-sm text-gray-400">Price: ₹{passwordDialog.course.price.toLocaleString()}</div>
              </div>

              <div className="space-y-2">
                <label className="text-sm text-gray-400">Course Password</label>
                <Input
                  type="password"
                  placeholder="Enter password to unlock"
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    setPasswordError('');
                  }}
                  className="bg-white/5 border-white/10 text-white placeholder:text-gray-600"
                  onKeyDown={(e) => e.key === 'Enter' && handlePasswordSubmit()}
                />
                {passwordError && (
                  <p className="text-sm text-red-400">{passwordError}</p>
                )}
              </div>

              <Button
                className="w-full bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600"
                onClick={handlePasswordSubmit}
              >
                Continue to Payment
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>

              <p className="text-xs text-center text-gray-500">
                Contact the course instructor to get the unlock password
              </p>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </section>
  );
}
