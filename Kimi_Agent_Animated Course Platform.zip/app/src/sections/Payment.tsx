import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Copy, 
  Check, 
  ArrowLeft, 
  Shield, 
  Clock,
  Smartphone,
  CreditCard
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useAppStore } from '@/store/appStore';

export function Payment() {
  const { 
    selectedCourseId, 
    getCourseById, 
    upiDetails, 
    createPurchase, 
    completePurchase,
    setView,
    showToast 
  } = useAppStore();

  const course = selectedCourseId ? getCourseById(selectedCourseId) : null;
  const [transactionId, setTransactionId] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);
  const [copied, setCopied] = useState(false);
  const [timeLeft, setTimeLeft] = useState(600); // 10 minutes
  const [purchase, setPurchase] = useState<{ id: string } | null>(null);

  useEffect(() => {
    if (course) {
      const newPurchase = createPurchase(course.id, course.price);
      setPurchase(newPurchase);
    }
  }, [course]);

  useEffect(() => {
    if (timeLeft > 0) {
      const timer = setInterval(() => setTimeLeft(t => t - 1), 1000);
      return () => clearInterval(timer);
    }
  }, [timeLeft]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleCopyUpi = () => {
    navigator.clipboard.writeText(upiDetails.vpa);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    showToast('UPI ID copied to clipboard', 'success');
  };

  const handleVerifyPayment = async () => {
    if (!transactionId.trim()) {
      showToast('Please enter transaction ID', 'error');
      return;
    }

    setIsVerifying(true);
    
    // Simulate verification
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    if (purchase) {
      completePurchase(purchase.id, transactionId);
      showToast('Payment verified successfully!', 'success');
      setView('student-dashboard');
    }
    
    setIsVerifying(false);
  };

  if (!course) {
    return (
      <div className="min-h-screen pt-24 flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-400">No course selected</p>
          <Button onClick={() => setView('courses')} className="mt-4">
            Browse Courses
          </Button>
        </div>
      </div>
    );
  }

  return (
    <section className="relative min-h-screen pt-24 pb-16">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Back button */}
        <motion.button
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          onClick={() => setView('courses')}
          className="flex items-center gap-2 text-gray-400 hover:text-white mb-6 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          Back to Courses
        </motion.button>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Left: Course Details */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            <div className="glass rounded-2xl overflow-hidden">
              <img
                src={course.thumbnail}
                alt={course.title}
                className="w-full h-48 object-cover"
              />
              <div className="p-5">
                <h2 className="text-xl font-semibold text-white mb-2">{course.title}</h2>
                <p className="text-gray-400 text-sm mb-4">{course.description}</p>
                
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">Instructor</span>
                    <span className="text-white">{course.instructor}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">Duration</span>
                    <span className="text-white">{course.duration}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">Level</span>
                    <span className="text-white capitalize">{course.level}</span>
                  </div>
                </div>

                <div className="mt-4 pt-4 border-t border-white/10">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-400">Total Amount</span>
                    <span className="text-2xl font-bold text-emerald-400">
                      ₹{course.price.toLocaleString()}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Security info */}
            <div className="glass rounded-xl p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-emerald-500/20 flex items-center justify-center">
                  <Shield className="w-5 h-5 text-emerald-400" />
                </div>
                <div>
                  <div className="font-medium text-white">Secure Payment</div>
                  <div className="text-sm text-gray-400">Your payment is protected</div>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Right: Payment */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="space-y-6"
          >
            {/* Timer */}
            <div className="glass rounded-xl p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Clock className="w-5 h-5 text-amber-400" />
                <span className="text-gray-400">Payment expires in</span>
              </div>
              <span className={`font-mono text-lg font-semibold ${timeLeft < 60 ? 'text-red-400' : 'text-white'}`}>
                {formatTime(timeLeft)}
              </span>
            </div>

            {/* UPI Payment */}
            <div className="glass rounded-2xl p-6">
              <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                <Smartphone className="w-5 h-5 text-emerald-400" />
                Pay via UPI
              </h3>

              {/* QR Code */}
              <div className="flex justify-center mb-6">
                <div className="relative">
                  <div className="w-48 h-48 bg-white rounded-xl p-4 flex items-center justify-center">
                    {/* Simulated QR Code */}
                    <div className="w-full h-full relative">
                      <svg viewBox="0 0 100 100" className="w-full h-full">
                        <rect fill="white" width="100" height="100"/>
                        {/* QR Pattern simulation */}
                        {[...Array(25)].map((_, i) => (
                          [...Array(25)].map((_, j) => (
                            Math.random() > 0.5 && (
                              <rect
                                key={`${i}-${j}`}
                                x={j * 4}
                                y={i * 4}
                                width="4"
                                height="4"
                                fill="black"
                              />
                            )
                          ))
                        ))}
                        {/* Position markers */}
                        <rect x="5" y="5" width="25" height="25" fill="black"/>
                        <rect x="10" y="10" width="15" height="15" fill="white"/>
                        <rect x="13" y="13" width="9" height="9" fill="black"/>
                        
                        <rect x="70" y="5" width="25" height="25" fill="black"/>
                        <rect x="75" y="10" width="15" height="15" fill="white"/>
                        <rect x="78" y="13" width="9" height="9" fill="black"/>
                        
                        <rect x="5" y="70" width="25" height="25" fill="black"/>
                        <rect x="10" y="75" width="15" height="15" fill="white"/>
                        <rect x="13" y="78" width="9" height="9" fill="black"/>
                      </svg>
                    </div>
                  </div>
                  <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 px-3 py-1 bg-emerald-500 rounded-full text-xs font-medium text-white">
                    Scan to Pay
                  </div>
                </div>
              </div>

              {/* UPI ID */}
              <div className="space-y-2 mb-6">
                <label className="text-sm text-gray-400">UPI ID</label>
                <div className="flex gap-2">
                  <div className="flex-1 px-4 py-3 rounded-xl bg-white/5 border border-white/10 font-mono text-white">
                    {upiDetails.vpa}
                  </div>
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={handleCopyUpi}
                    className="border-white/10 hover:bg-white/5"
                  >
                    {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                  </Button>
                </div>
              </div>

              {/* Or pay via app */}
              <div className="text-center mb-6">
                <span className="text-sm text-gray-500">or pay using any UPI app</span>
              </div>

              <div className="grid grid-cols-4 gap-3 mb-6">
                {['GPay', 'PhonePe', 'Paytm', 'BHIM'].map((app) => (
                  <button
                    key={app}
                    className="p-3 rounded-xl bg-white/5 hover:bg-white/10 transition-colors text-center"
                  >
                    <div className="w-8 h-8 mx-auto mb-1 rounded-full bg-gradient-to-br from-emerald-400 to-teal-500 flex items-center justify-center text-xs font-bold text-white">
                      {app[0]}
                    </div>
                    <span className="text-xs text-gray-400">{app}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Transaction ID */}
            <div className="glass rounded-2xl p-6">
              <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                <CreditCard className="w-5 h-5 text-emerald-400" />
                Verify Payment
              </h3>
              
              <div className="space-y-4">
                <div>
                  <label className="text-sm text-gray-400 mb-2 block">
                    Enter UPI Transaction ID
                  </label>
                  <Input
                    placeholder="e.g., UPI1234567890"
                    value={transactionId}
                    onChange={(e) => setTransactionId(e.target.value)}
                    className="bg-white/5 border-white/10 text-white placeholder:text-gray-600"
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    You can find this in your UPI app transaction history
                  </p>
                </div>

                <Button
                  className="w-full bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600"
                  onClick={handleVerifyPayment}
                  disabled={isVerifying}
                >
                  {isVerifying ? (
                    <>
                      <motion.div
                        animate={{ rotate: 360 }}
                        transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                        className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full mr-2"
                      />
                      Verifying...
                    </>
                  ) : (
                    'Verify & Unlock Course'
                  )}
                </Button>
              </div>
            </div>

            {/* Help */}
            <p className="text-center text-sm text-gray-500">
              Having trouble?{' '}
              <button className="text-emerald-400 hover:underline">
                Contact Support
              </button>
            </p>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
